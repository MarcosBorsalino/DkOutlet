// JavaScript Document

$(function(){
	  $("#carrossel").jCarouselLite({
			btnPrev : '.prev',
			btnNext : '.next',
			auto    : 4000,
			speed   : 2000,
			visible : 6
	  })
})
